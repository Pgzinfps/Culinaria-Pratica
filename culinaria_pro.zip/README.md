
# Culinária Pro

Site estático de receitas - pronto para deploy no Netlify.

## Estrutura
- `index.html` - Página inicial
- `receitas.html` - Lista de receitas
- `sobre.html` - Sobre
- `contato.html` - Formulário de contato (demo salvo no localStorage)
- `admin.html` - Painel admin simples (demo usando localStorage)
- `assets/` - CSS, JS, imagens e favicon

## Como publicar no Netlify
1. Crie um repositório no GitHub e faça push dos arquivos.
2. No Netlify: Add new site → Import from GitHub → selecione o repositório.
3. Build command: (deixe em branco)
4. Publish directory: `.`
5. Deploy!

## Domínio personalizado
Para usar seu domínio (ex.: seu-dominio.uk):
- No Netlify → Site settings → Domain management → Add custom domain
- No seu provedor DNS (Cloudflare): crie um registro CNAME apontando para `seu-site.netlify.app`

## Observações
- Este projeto é um **demo**: o painel admin e o contato salvam apenas no navegador (localStorage). Para produção, conecte a uma API ou serviço de backend.
- Fique à vontade para personalizar as cores, fontes e conteúdo.
