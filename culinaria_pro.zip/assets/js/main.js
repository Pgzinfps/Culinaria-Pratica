
/* main site JS */
const RECIPES = [
  {
    id:1, title: 'Bolo de Banana Rápido', img:'https://images.unsplash.com/photo-1542446659-3a9e5a1d1f4a',
    desc:'Bolo fofinho feito com bananas maduras — sem açúcar opcional.',
    time:'20 min', tags:['doce','rápido','vegano opcional'],
    ingredients:['3 bananas maduras','2 ovos','1/2 xícara de óleo','1 xícara de farinha','1 colher de fermento'],
    steps:['Amasse as bananas.','Misture os ovos e o óleo.','Adicione a farinha e o fermento.','Asse 35 minutos a 180°C.']
  },
  {
    id:2, title:'Arroz Cremoso com Cogumelos', img:'https://images.unsplash.com/photo-1543353071-087092ec3933',
    desc:'Arroz tipo risoto, cremoso e fácil de fazer na panela comum.',
    time:'30 min', tags:['principal','vegetariano'],
    ingredients:['1 xícara de arroz','200g cogumelos','1/2 cebola','caldo de legumes','queijo opcional'],
    steps:['Refogue a cebola e cogumelos.','Adicione o arroz e o caldo aos poucos.','Cozinhe até ficar cremoso.','Finalize com queijo se desejar.']
  },
  {
    id:3, title:'Salada de Grão-de-bico', img:'https://images.unsplash.com/photo-1543353071-087092ec3933',
    desc:'Salada fresca, rica em proteínas e fácil de montar.',
    time:'10 min', tags:['salada','rápido','vegano'],
    ingredients:['1 lata de grão-de-bico','tomate','pepino','azeite','suco de limão'],
    steps:['Misture os ingredientes.','Tempere com azeite e limão.','Sirva fria.']
  }
];

function initSite(){
  const grid = document.getElementById('recipesGrid');
  const searchInput = document.getElementById('search');
  const modal = document.getElementById('modal');
  const modalTitle = document.getElementById('modalTitle');
  const modalImage = document.getElementById('modalImage');
  const modalDesc = document.getElementById('modalDesc');
  const modalSteps = document.getElementById('modalSteps');
  const modalIngredients = document.getElementById('modalIngredients');
  const modalTime = document.getElementById('modalTime');
  const modalTags = document.getElementById('modalTags');

  function renderCard(recipe){
    const el = document.createElement('div'); el.className='card';
    el.innerHTML = `
      <div class="img" style="background-image:url('${recipe.img}&w=800&q=60')"></div>
      <div class="title">${recipe.title}</div>
      <div class="meta">${recipe.desc}</div>
      <div class="tags">${recipe.tags.map(t=>`<div class="tag-pill">${t}</div>`).join('')}</div>
      <div style="margin-top:12px;display:flex;justify-content:space-between;align-items:center">
        <div class="muted">${recipe.time}</div>
        <button class="btn" data-id="${recipe.id}">Ver</button>
      </div>
    `;
    grid.appendChild(el);
  }

  function loadRecipes(list){
    grid.innerHTML='';
    list.forEach(r=>renderCard(r));
    document.querySelectorAll('.card .btn').forEach(b=>b.addEventListener('click',e=>{
      const id = Number(e.currentTarget.dataset.id);
      openModal(RECIPES.find(x=>x.id===id));
    }))
  }

  function openModal(recipe){
    modalTitle.textContent = recipe.title;
    modalImage.style.backgroundImage = `url('${recipe.img}&w=1200&q=80')`;
    modalDesc.textContent = recipe.desc;
    modalSteps.innerHTML = recipe.steps.map(s=>`<div>• ${s}</div>`).join('');
    modalIngredients.innerHTML = recipe.ingredients.map(i=>`<li>${i}</li>`).join('');
    modalTime.textContent = recipe.time;
    modalTags.innerHTML = recipe.tags.map(t=>`<div class="tag-pill">${t}</div>`).join('');
    modal.style.display = 'flex';
  }

  document.getElementById('closeModal').addEventListener('click',()=>{modal.style.display='none'});
  modal.addEventListener('click',(e)=>{ if(e.target===modal) modal.style.display='none' });

  searchInput.addEventListener('input',()=>{
    const q = searchInput.value.trim().toLowerCase();
    if(!q) return loadRecipes(RECIPES);
    const filtered = RECIPES.filter(r=>
      r.title.toLowerCase().includes(q) || r.desc.toLowerCase().includes(q) || r.tags.join(' ').toLowerCase().includes(q) || r.ingredients.join(' ').toLowerCase().includes(q)
    );
    loadRecipes(filtered);
  });

  document.getElementById('subscribeBtn').addEventListener('click',()=>{
    const email = document.getElementById('email').value.trim();
    if(!email || !email.includes('@')) return alert('Digite um e-mail válido.');
    localStorage.setItem('culinaria_email',email);
    alert('Obrigado! Você será notificado (demo).');
  });

  document.getElementById('newRecipeBtn').addEventListener('click',()=>{
    const title = prompt('Nome da receita:');
    if(!title) return;
    const r = {id:Date.now(), title, img:'https://images.unsplash.com/photo-1523986371872-9d3ba2e2f642', desc:'Receita adicionada pelo usuário', time:'—', tags:['minha'], ingredients:[], steps:['Descrição não disponível.']};
    RECIPES.unshift(r); loadRecipes(RECIPES);
  });

  loadRecipes(RECIPES);
}

document.addEventListener('DOMContentLoaded', initSite);
